# uwid_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('classifier/', include('classifier.urls')),
    # Add a pattern for the empty path
    path('', include('classifier.urls')),  # Assuming 'classifier.urls' contains the view for the home page
]
