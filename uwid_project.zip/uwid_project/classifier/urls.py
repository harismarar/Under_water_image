# uwid_project/classifier/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.classify_image, name='classify_image'),
    path('model_architecture/', views.model_architecture_view, name='model_architecture'),
]
