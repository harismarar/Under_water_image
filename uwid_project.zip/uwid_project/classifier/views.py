from django.shortcuts import render
from .forms import ImageUploadForm  # Import the ImageUploadForm class
from .models import UnderwaterImageClassifier
from tensorflow.keras.preprocessing import image
import os
import numpy as np
from PIL import Image
from io import BytesIO
import base64


from django.shortcuts import render

def model_architecture_view(request):
    return render(request, 'classifier/model_architecture.html')



# Define class names based on your performance metrics
class_names = [
    "Whale", "Turtle", "Starfish", "Sea_Urchins", 
    "Sea_Rays", "Penguin", "Otter", "Jelly_Fish", 
    "Fish", "Clams"
]

def classify_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            image_file = request.FILES['image']
            # Load your model
            model_path = "D:/projects/UWID/uwid_project/UWID310.h5"  # Update this with your model path
            classifier = UnderwaterImageClassifier(model_path=model_path)
            # Load the image and preprocess it
            image_content = image_file.read()
            img = Image.open(BytesIO(image_content))
            img = img.resize((224, 224))  # Resize the image to match the input size of your model
            img_array = np.array(img)
            img_array = img_array.astype('float32') / 255  # Normalize the pixel values
            img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
            # Make prediction
            predictions = classifier.predict(img_array)
            predicted_class = np.argmax(predictions)
            # Get the predicted class name from the class names list
            predicted_class_name = class_names[predicted_class]
            # Encode the image content to base64
            image_content_base64 = base64.b64encode(image_content).decode('utf-8')
            context = {
                'predicted_class': predicted_class_name,
                'image_content': image_content_base64  # Pass the base64-encoded image content to the context
            }
            return render(request, 'classifier/result.html', context)
    else:
        form = ImageUploadForm()
    return render(request, 'classifier/upload.html', {'form': form})
