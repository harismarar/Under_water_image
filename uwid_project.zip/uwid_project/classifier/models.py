from django.db import models

# Create your models here.
# classifier/model.py
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np

class UnderwaterImageClassifier:
    def __init__(self, model_path):
        self.model = load_model(model_path)

    def predict(self, img_array):
        # Make prediction
        predictions = self.model.predict(img_array)
        return predictions
